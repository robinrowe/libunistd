var qio_8c =
[
    [ "MAX_IOSEND_SIZE", "qio_8c.html#a52246cf5f9d0bf7f359dfc0f92d555ed", null ],
    [ "qio_wait_readable", "qio_8c.html#a8a695a43ebb605d243e56ad48937862e", null ],
    [ "qio_wait_writable", "qio_8c.html#ac905811f0daa394ffef7beab68585a55", null ],
    [ "qio_read", "qio_8c.html#aa34911362f1793ed1e744d3eb63500db", null ],
    [ "qio_write", "qio_8c.html#a0645cf0a3bcfc79ee3829012243d46d8", null ],
    [ "qio_send", "qio_8c.html#aafd34a0ab9f916ded37b1634cac3ab6a", null ],
    [ "qio_gets", "qio_8c.html#ab7ce64cc8cd837de47c91d1bdcb17cf5", null ],
    [ "qio_puts", "qio_8c.html#a2c00200ce1766b2b81dafd9b9f20f6d0", null ],
    [ "qio_printf", "qio_8c.html#ad2b7b0e9eb6e217a36422de18570b4e3", null ]
];