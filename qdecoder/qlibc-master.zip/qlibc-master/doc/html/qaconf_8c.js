var qaconf_8c =
[
    [ "qaconf", "qaconf_8c.html#ac28c668ae735bb483d2c61c59f54cae0", null ],
    [ "addoptions", "qaconf_8c.html#a4b7d9693f31e326b134f03f8ee4bca09", null ],
    [ "setdefhandler", "qaconf_8c.html#a440db32385534bf03f08de253737623b", null ],
    [ "setuserdata", "qaconf_8c.html#ab68c8ab80781fbca3aeaf7e3d16a9cc2", null ],
    [ "parse", "qaconf_8c.html#a1ee9ebbb7719b530a788d2d01256b2cc", null ],
    [ "errmsg", "qaconf_8c.html#a5c09256d455a4cf7443aca42bccdf0e0", null ],
    [ "reseterror", "qaconf_8c.html#abad17eff2cc816719fdba22f271b0aab", null ],
    [ "free_", "qaconf_8c.html#abfcdc4a8d1067527f4c2d99b29d0db39", null ]
];