var qtokenbucket_8c =
[
    [ "qtokenbucket_init", "qtokenbucket_8c.html#a8da36d9c0f027f0a24086526593e2eab", null ],
    [ "qtokenbucket_consume", "qtokenbucket_8c.html#aec09c4e8a1ef411e4a5ee6d9036dbca0", null ],
    [ "qtokenbucket_waittime", "qtokenbucket_8c.html#a5464647c7e3874f8517fdbe787ee6ce3", null ]
];