var qsocket_8c =
[
    [ "qsocket_open", "qsocket_8c.html#a86e043367b6ba401408c64736192319d", null ],
    [ "qsocket_close", "qsocket_8c.html#a536b1963c73ec5ace917a57ffed1f3cd", null ],
    [ "qsocket_get_addr", "qsocket_8c.html#a4285c6dd3c52560f3d471f332f6558bc", null ],
    [ "qsocket_get_localaddr", "qsocket_8c.html#aac413225be88d873f0d6f19f2ee5e42b", null ]
];