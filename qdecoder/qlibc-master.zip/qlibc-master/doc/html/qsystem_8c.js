var qsystem_8c =
[
    [ "qgetenv", "qsystem_8c.html#a572fee0d88280a0dd1f5ab0905296eea", null ],
    [ "qsyscmd", "qsystem_8c.html#a5463b8e0d69c2f317da6d9c47dee14f4", null ]
];